//active
debugger;
import {rs as addBasis} from '/mlib/basics.mjs';
let rs = containerShape.mk();
addBasis(rs);
export {rs};
